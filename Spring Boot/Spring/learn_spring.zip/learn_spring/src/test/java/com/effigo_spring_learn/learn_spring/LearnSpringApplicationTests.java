package com.effigo_spring_learn.learn_spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearnSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
