package com.learn.maven_spring.learn_maven_spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearnMavenSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
